const express = require("express");
const session = require("express-session");
const SQLiteStore = require("connect-sqlite3")(session);
const bcrypt = require("bcryptjs");
const Database = require("better-sqlite3");
const multer = require("multer");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;
const SITE_URL = (process.env.SITE_URL || "").replace(/\/+$/, "");
const GOOGLE_VERIFY = (process.env.GOOGLE_SITE_VERIFICATION || "").replace(/[^A-Za-z0-9_-]/g, "");
const IS_PROD = process.env.NODE_ENV === "production";

if (!ADMIN_USER || ADMIN_USER.length < 4 || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 12 || !SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.error("ADMIN_USER (4+ characters), ADMIN_PASSWORD (12+ characters) aur SESSION_SECRET (32+ characters) set karna zaroori hai.");
  process.exit(1);
}
if (IS_PROD && !SITE_URL) {
  console.warn("Warning: SITE_URL set nahi hai. Sitemap aur Google ke liye apna domain (https://aapka-domain.com) SITE_URL me daalein.");
}

const passwordHash = bcrypt.hashSync(ADMIN_PASSWORD, 12);
const root = __dirname;
// DATA_DIR: database, sessions aur uploads yahin rakhe jaate hain. Hosting par is folder ko persistent disk se jodein.
const dataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : root;
const uploadDir = path.join(dataDir, "uploads");
fs.mkdirSync(uploadDir, { recursive: true });

const db = new Database(path.join(dataDir, "news.db"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS site_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
  CREATE TABLE IF NOT EXISTS news (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    body TEXT NOT NULL,
    image TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  );
`);

const categories = ["Railway", "Public Awareness", "Civil Sense", "Your Rights"];
const categoryLabels = { Railway: "रेलवे न्यूज़", "Public Awareness": "जन-जागरूकता", "Civil Sense": "सिविल सेंस", "Your Rights": "आपके अधिकार" };
const extByType = { "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp" };

const storage = multer.diskStorage({
  destination: (_, __, cb) => cb(null, uploadDir),
  filename: (_, file, cb) => cb(null, Date.now() + "-" + Math.random().toString(36).slice(2) + (extByType[file.mimetype] || ".bin"))
});
const upload = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (_, file, cb) => {
    const ok = Object.prototype.hasOwnProperty.call(extByType, file.mimetype);
    cb(ok ? null : new Error("Only JPG, PNG and WEBP images are allowed."), ok);
  }
});

const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const baseUrl = (req) => SITE_URL || `${req.protocol}://${req.get("host")}`;
const toIso = (s) => { const d = new Date(String(s).replace(" ", "T") + "Z"); return isNaN(d) ? new Date().toISOString() : d.toISOString(); };
const getSetting = (key) => { const r = db.prepare("SELECT value FROM site_settings WHERE key=?").get(key); return r ? r.value : null; };
function removeUpload(url) {
  if (url && url.startsWith("/uploads/")) {
    const p = path.join(uploadDir, path.basename(url));
    if (fs.existsSync(p)) fs.unlinkSync(p);
  }
}

app.disable("x-powered-by");
app.set("trust proxy", 1); // Render/Railway/Nginx jaise proxy ke peeche HTTPS cookie sahi chale
app.use(helmet({
  contentSecurityPolicy: {
    useDefaults: true,
    directives: {
      "default-src": ["'self'"],
      "script-src": ["'self'"],
      "style-src": ["'self'", "https://fonts.googleapis.com"],
      "font-src": ["'self'", "https://fonts.gstatic.com"],
      "img-src": ["'self'", "data:"],
      "connect-src": ["'self'"],
      "frame-ancestors": ["'none'"],
      "form-action": ["'self'"],
      "upgrade-insecure-requests": IS_PROD ? [] : null
    }
  }
}));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

// Dusri website se aayi badlav wali request band
app.use((req, res, next) => {
  if (["POST", "PUT", "PATCH", "DELETE"].includes(req.method)) {
    const origin = req.get("origin");
    if (origin) {
      let ok = false;
      try { ok = new URL(origin).host === req.get("host"); } catch (e) { ok = false; }
      if (!ok) return res.status(403).json({ error: "Yeh request allowed nahi hai." });
    }
  }
  next();
});

app.use(session({
  store: new SQLiteStore({ db: "sessions.sqlite", dir: dataDir }),
  name: "golu_news_session",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: IS_PROD, maxAge: 8 * 60 * 60 * 1000 }
}));

app.use("/uploads", express.static(uploadDir, { fallthrough: false, maxAge: "7d" }));

function requireAdmin(req, res, next) {
  if (req.session && req.session.admin === true) return next();
  return res.status(401).json({ error: "Admin login zaroori hai." });
}

// ---------- SEO: homepage, article pages, sitemap, robots ----------
const indexHtml = fs.readFileSync(path.join(root, "public", "index.html"), "utf8");
const SITE_NAME = "Golu Jonwal News";
const SITE_DESC = "Golu Jonwal News पर पढ़ें रेलवे, जन-जागरूकता, सिविल सेंस और आपके अधिकारों से जुड़ी ताज़ा खबरें, आसान भाषा में।";

function jsonLd(obj) { return `<script type="application/ld+json">${JSON.stringify(obj).replace(/</g, "\\u003c")}</script>`; }

app.get(["/", "/index.html"], (req, res) => {
  const base = baseUrl(req);
  const banner = getSetting("banner_photo");
  const profile = getSetting("profile_photo");
  const image = banner || profile;
  const seo = [
    `<link rel="canonical" href="${esc(base)}/">`,
    `<meta property="og:type" content="website"><meta property="og:site_name" content="${SITE_NAME}">`,
    `<meta property="og:title" content="${SITE_NAME} | आपकी आवाज़, आपकी खबर"><meta property="og:description" content="${esc(SITE_DESC)}">`,
    `<meta property="og:url" content="${esc(base)}/">`,
    image ? `<meta property="og:image" content="${esc(base + image)}">` : "",
    `<meta name="twitter:card" content="${image ? "summary_large_image" : "summary"}">`,
    GOOGLE_VERIFY ? `<meta name="google-site-verification" content="${GOOGLE_VERIFY}">` : "",
    jsonLd({ "@context": "https://schema.org", "@type": "NewsMediaOrganization", name: SITE_NAME, url: base + "/", sameAs: ["https://instagram.com/its_golu_jonwal"] })
  ].join("\n");
  res.type("html").send(indexHtml.replace("<!--SEO-->", seo));
});

app.get("/khabar/:id(\\d+)", (req, res) => {
  const n = db.prepare("SELECT id,title,category,body,image,created_at FROM news WHERE id=?").get(req.params.id);
  if (!n) return res.status(404).type("html").send(`<!doctype html><html lang="hi"><meta charset="utf-8"><meta name="robots" content="noindex"><title>खबर नहीं मिली | ${SITE_NAME}</title><link rel="stylesheet" href="/style.css"><body class="article-body"><main class="article"><h1>यह खबर नहीं मिली</h1><p><a href="/">होमपेज पर जाएँ</a></p></main></body></html>`);
  const base = baseUrl(req);
  const url = `${base}/khabar/${n.id}`;
  const desc = n.body.replace(/\s+/g, " ").trim().slice(0, 155);
  const iso = toIso(n.created_at);
  const paragraphs = n.body.split(/\n+/).filter(Boolean).map((p) => `<p>${esc(p)}</p>`).join("\n");
  const ld = {
    "@context": "https://schema.org", "@type": "NewsArticle", headline: n.title.slice(0, 110), datePublished: iso, dateModified: iso,
    mainEntityOfPage: url, author: { "@type": "Organization", name: SITE_NAME },
    publisher: { "@type": "Organization", name: SITE_NAME, url: base + "/" }
  };
  if (n.image) ld.image = [base + n.image];
  res.type("html").send(`<!doctype html>
<html lang="hi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(n.title)} | ${SITE_NAME}</title>
<meta name="description" content="${esc(desc)}">
<link rel="canonical" href="${esc(url)}">
<meta property="og:type" content="article"><meta property="og:site_name" content="${SITE_NAME}"><meta property="og:title" content="${esc(n.title)}"><meta property="og:description" content="${esc(desc)}"><meta property="og:url" content="${esc(url)}">
${n.image ? `<meta property="og:image" content="${esc(base + n.image)}">` : ""}
<meta name="twitter:card" content="${n.image ? "summary_large_image" : "summary"}">
${GOOGLE_VERIFY ? `<meta name="google-site-verification" content="${GOOGLE_VERIFY}">` : ""}
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Hind:wght@400;500;600;700&family=Inter:wght@800;900&display=swap" rel="stylesheet">
<link rel="stylesheet" href="/style.css">
${jsonLd(ld)}
</head><body class="article-body">
<header class="article-top"><div class="container"><a href="/">← ${SITE_NAME}</a></div></header>
<main class="article container">
<p class="eyebrow">${esc(categoryLabels[n.category] || n.category)}</p>
<h1>${esc(n.title)}</h1>
<p class="date">${esc(new Date(iso).toLocaleDateString("hi-IN", { timeZone: "Asia/Kolkata" }))}</p>
${n.image ? `<img class="article-img" src="${esc(n.image)}" alt="${esc(n.title)}">` : ""}
${paragraphs}
<p class="article-back"><a href="/">और खबरें पढ़ें →</a></p>
</main>
<footer><div class="copyright">© ${new Date().getFullYear()} ${SITE_NAME}. All rights reserved.</div></footer>
</body></html>`);
});

app.get("/sitemap.xml", (req, res) => {
  const base = baseUrl(req);
  const rows = db.prepare("SELECT id,created_at FROM news ORDER BY id DESC LIMIT 5000").all();
  const urls = [`<url><loc>${esc(base)}/</loc></url>`].concat(rows.map((r) => `<url><loc>${esc(base)}/khabar/${r.id}</loc><lastmod>${toIso(r.created_at).slice(0, 10)}</lastmod></url>`));
  res.type("application/xml").send(`<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n${urls.join("\n")}\n</urlset>`);
});

app.get("/robots.txt", (req, res) => {
  res.type("text/plain").send(`User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${baseUrl(req)}/sitemap.xml\n`);
});

app.use(express.static(path.join(root, "public"), { index: false }));

// ---------- API ----------
app.get("/api/site-profile", (_, res) => {
  res.json({ profilePhoto: getSetting("profile_photo"), bannerPhoto: getSetting("banner_photo") });
});

function photoRoutes(pathName, settingKey) {
  app.post(pathName, requireAdmin, upload.single("image"), (req, res) => {
    if (!req.file) return res.status(400).json({ error: "कृपया फोटो चुनें।" });
    removeUpload(getSetting(settingKey));
    const photo = "/uploads/" + req.file.filename;
    db.prepare("INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value").run(settingKey, photo);
    res.json({ ok: true, photo });
  });
  app.delete(pathName, requireAdmin, (req, res) => {
    removeUpload(getSetting(settingKey));
    db.prepare("DELETE FROM site_settings WHERE key=?").run(settingKey);
    res.json({ ok: true });
  });
}
photoRoutes("/api/site-profile/photo", "profile_photo");
photoRoutes("/api/site-banner/photo", "banner_photo");

app.get("/api/news", (_, res) => {
  res.json(db.prepare("SELECT id,title,category,body,image,created_at FROM news ORDER BY id DESC").all());
});

const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 10,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: "Bahut zyada koshish ho gayi. 15 minute baad dobara try karein." }
});
app.post("/api/login", loginLimiter, async (req, res) => {
  const { username, password } = req.body || {};
  const userOk = typeof username === "string" && username === ADMIN_USER;
  const passOk = typeof password === "string" && await bcrypt.compare(password, passwordHash);
  if (!(userOk && passOk)) return res.status(401).json({ error: "Username ya password galat hai." });
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: "Login abhi nahi ho saka." });
    req.session.admin = true;
    res.json({ ok: true });
  });
});
app.get("/api/session", (req, res) => res.json({ admin: !!(req.session && req.session.admin) }));
app.post("/api/logout", requireAdmin, (req, res) => req.session.destroy(() => res.json({ ok: true })));

app.post("/api/news", requireAdmin, upload.single("image"), (req, res) => {
  const { title, category, body } = req.body || {};
  if (!title || !category || !body || !categories.includes(category)) {
    if (req.file) fs.unlinkSync(req.file.path);
    return res.status(400).json({ error: "Title, valid category aur news detail bharna zaroori hai." });
  }
  const image = req.file ? "/uploads/" + req.file.filename : null;
  const result = db.prepare("INSERT INTO news(title,category,body,image) VALUES(?,?,?,?)").run(title.trim().slice(0, 180), category, body.trim(), image);
  res.json({ ok: true, id: result.lastInsertRowid });
});
app.delete("/api/news/:id", requireAdmin, (req, res) => {
  const item = db.prepare("SELECT image FROM news WHERE id=?").get(req.params.id);
  if (item) removeUpload(item.image);
  db.prepare("DELETE FROM news WHERE id=?").run(req.params.id);
  res.json({ ok: true });
});

app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  res.status(400).json({ error: err.message || "Request process nahi ho saki." });
});
app.listen(PORT, () => console.log(`Golu Jonwal News running on port ${PORT}`));
