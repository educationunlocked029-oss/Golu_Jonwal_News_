const $=s=>document.querySelector(s);
let allNews=[],activeCategory="All";
const labels={Railway:"रेलवे न्यूज़","Public Awareness":"जन-जागरूकता","Civil Sense":"सिविल सेंस","Your Rights":"आपके अधिकार"};
const esc=s=>String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function loadProfile(){
 try { const p=await fetch("/api/site-profile").then(r=>r.json());
 document.querySelectorAll(".brand-icon").forEach(w=>{const img=w.querySelector("img"),globe=w.querySelector(".globe");
  if(p.profilePhoto){img.src=p.profilePhoto;img.hidden=false;globe.hidden=true;} else {img.hidden=true;globe.hidden=false;}});
 const tb=$("#topBanner"); if(p.bannerPhoto){$("#topBannerImg").src=p.bannerPhoto;tb.hidden=false;} else {tb.hidden=true;} } catch(e){}
}
async function loadNews(){
 try{allNews=await fetch("/api/news").then(r=>r.json());renderNews();renderManage()}
 catch(e){$("#newsGrid").innerHTML='<p class="empty">खबरें लोड नहीं हो सकीं। कृपया बाद में कोशिश करें।</p>'}
}
function renderNews(){
 const items=activeCategory==="All"?allNews:allNews.filter(n=>n.category===activeCategory);
 $("#newsGrid").innerHTML=items.length?items.map(n=>`<article class="news-card">${n.image?`<img src="${esc(n.image)}" alt="News image" loading="lazy">`:""}<div class="news-content"><span class="tag">${labels[n.category]||esc(n.category)}</span><h3><a class="news-link" href="/khabar/${Number(n.id)}">${esc(n.title)}</a></h3><p>${esc(n.body)}</p><span class="date">${new Date(n.created_at+"Z").toLocaleDateString("hi-IN")}</span></div></article>`).join(""):'<p class="empty">इस category में अभी कोई खबर प्रकाशित नहीं हुई है।</p>';
}
function renderManage(){
 $("#manageList").innerHTML=allNews.length?allNews.map(n=>`<div class="manage-item"><span>${esc(n.title)}</span><button class="delete-btn" data-delete="${n.id}">Delete</button></div>`).join(""):"<p class='muted'>अभी कोई खबर प्रकाशित नहीं है।</p>";
}
$("#filters").addEventListener("click",e=>{const b=e.target.closest("[data-cat]");if(!b)return;activeCategory=b.dataset.cat;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));renderNews()});
$("#year").textContent=new Date().getFullYear();
const modal=$("#adminModal");
$("#openAdmin").onclick=()=>{modal.classList.add("show");modal.setAttribute("aria-hidden","false")};
$("#closeAdmin").onclick=()=>{modal.classList.remove("show");modal.setAttribute("aria-hidden","true")};
modal.addEventListener("click",e=>{if(e.target===modal)$("#closeAdmin").click()});
async function showSession(){const s=await fetch("/api/session").then(r=>r.json());$("#loginView").hidden=s.admin;$("#dashboard").hidden=!s.admin;if(s.admin)renderManage()}
showSession();
loadProfile();
$("#loginForm").onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.target));const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});const j=await r.json();if(!r.ok){$("#loginError").textContent=j.error;return}$("#loginError").textContent="";$("#loginView").hidden=true;$("#dashboard").hidden=false;renderManage()};
$("#newsForm").onsubmit=async e=>{e.preventDefault();const r=await fetch("/api/news",{method:"POST",body:new FormData(e.target)});const j=await r.json();$("#adminMessage").textContent=r.ok?"खबर सफलतापूर्वक publish हो गई।":(j.error||"Error");if(r.ok){e.target.reset();await loadNews()}};
$("#manageList").addEventListener("click",async e=>{const b=e.target.closest("[data-delete]");if(!b)return;if(!confirm("क्या आप यह खबर हटाना चाहते हैं?"))return;const r=await fetch("/api/news/"+b.dataset.delete,{method:"DELETE"});if(r.ok){await loadNews();$("#adminMessage").textContent="खबर हटा दी गई।"}});
$("#logout").onclick=async()=>{await fetch("/api/logout",{method:"POST"});$("#dashboard").hidden=true;$("#loginView").hidden=false;$("#loginForm").reset();$("#closeAdmin").click()};
loadNews();
$("#profileForm").onsubmit=async e=>{e.preventDefault();const r=await fetch("/api/site-profile/photo",{method:"POST",body:new FormData(e.target)});const j=await r.json();$("#profileMessage").textContent=r.ok?"वेबसाइट DP अपडेट हो गई।":(j.error||"अपडेट नहीं हो सका।");if(r.ok){e.target.reset();loadProfile()}};
$("#removeProfile").onclick=async()=>{if(!confirm("क्या वेबसाइट की DP हटानी है?"))return;const r=await fetch("/api/site-profile/photo",{method:"DELETE"});if(r.ok){$("#profileMessage").textContent="DP हटा दी गई।";loadProfile()}};
document.querySelectorAll("[data-navcat]").forEach(a=>a.addEventListener("click",()=>{activeCategory=a.dataset.navcat;document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x.dataset.cat===activeCategory));renderNews()}));
$("#bannerForm").onsubmit=async e=>{e.preventDefault();const r=await fetch("/api/site-banner/photo",{method:"POST",body:new FormData(e.target)});const j=await r.json();$("#bannerMessage").textContent=r.ok?"बैनर फोटो अपडेट हो गई।":(j.error||"अपडेट नहीं हो सका।");if(r.ok){e.target.reset();loadProfile()}};
$("#removeBanner").onclick=async()=>{if(!confirm("क्या बैनर फोटो हटानी है?"))return;const r=await fetch("/api/site-banner/photo",{method:"DELETE"});if(r.ok){$("#bannerMessage").textContent="बैनर हटा दिया गया।";loadProfile()}};
